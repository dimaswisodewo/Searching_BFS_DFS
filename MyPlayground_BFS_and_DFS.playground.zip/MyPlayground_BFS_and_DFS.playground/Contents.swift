import Foundation

// Find shortest path with DFS
func dfsShortestPath(graph: [Int: [Int]], origin: Int, target: Int, _ visited: inout Set<Int>, _ path: inout [Int], _ shortestPath: inout [Int]?) {
    
    // Track current path
    visited.insert(origin)
    path.append(origin)

    print("Visited \(origin)")
    
    if origin == target {
        // Arrived at destination
        if shortestPath == nil || path.count < shortestPath!.count {
            shortestPath = path
        }
    } else {
        // Get neighbor nodes
        if let neighbors = graph[origin] {
            for neighbor in neighbors {
                if !visited.contains(neighbor) {
                    // Do recursion
                    dfsShortestPath(graph: graph, origin: neighbor, target: target, &visited, &path, &shortestPath)
                }
            }
        }
    }

    // Reset current path
    visited.remove(origin)
    path.removeLast()
}

// Find shortest path with BFS
func bfsShortestPath(graph: [Int: [Int]], origin: Int, target: Int) -> [Int]? {
    
    var queue: [(node: Int, path: [Int])] = [(origin, [origin])]
    var visited: Set<Int> = [origin]
    
    while !queue.isEmpty {
        let (current, path) = queue.removeFirst()
        
        print("Visited \(current)")
        
        if current == target {
            return path
        }
        
        if let neighbors = graph[current] {
            for neighbor in neighbors {
                if !visited.contains(neighbor) {
                    visited.insert(neighbor)
                    queue.append((neighbor, path + [neighbor]))
                }
            }
        }
    }
    
    return nil
}

// Example usage
let graph = [
    1: [2, 3],
    2: [4, 5],
    3: [5, 6],
    4: [6],
    5: [6],
    6: []
]

var visited: Set<Int> = []
var path: [Int] = []
var shortestPath: [Int]? = nil

dfsShortestPath(graph: graph, origin: 1, target: 6, &visited, &path, &shortestPath)

if let path = shortestPath {
    print("DFS shortest path: \(path)\n")
} else {
    print("No path found.\n")
}

if let path = bfsShortestPath(graph: graph, origin: 1, target: 6) {
    print("BFS shortest path: \(path)\n")
} else {
    print("No path found.\n")
}

// Find route with cheapest cost using DFS
func dfsShortestRoute(routes: [String: [String: Int]], origin: String, target: String, additionalCost: Int, _ visited: inout Set<String>, _ currentRoute: inout [String], _ cheapestRoute: inout [String], _ currentCost: inout Int, _ cheapestCost: inout Int) {
    
    // Track current route & cost
    visited.insert(origin)
    currentRoute.append(origin)
    currentCost += additionalCost
    
    print("Visited \(origin)")
    
    if origin == target {
        // Arrived at destination
        if currentCost < cheapestCost {
            cheapestCost = currentCost
            cheapestRoute = currentRoute
        }
    } else {
        // Get neighbor cities
        if let neighbors = routes[origin] {
            for neighbor in neighbors {
                if !visited.contains(neighbor.key) {
                    // Do recursion
                    dfsShortestRoute(routes: routes, origin: neighbor.key, target: target, additionalCost: neighbor.value, &visited, &currentRoute, &cheapestRoute, &currentCost, &cheapestCost)
                }
            }
        }
    }
    
    // Reset current route & cost
    visited.remove(origin)
    currentRoute.removeLast()
    currentCost -= additionalCost
}

// Find route with cheapest cost with BFS
func bfsShortestRoute(routes: [String: [String: Int]], origin: String, target: String, cheapestCost: inout Int, cheapestRoute: inout [String]) {
    
    // Track routes and costs
    var queue: [(city: String, cityRoute: [String], currentCost: Int)] = [(origin, [origin], 0)]
    var visited: Set<String> = [origin]
    
    while !queue.isEmpty {
        let (origin, route, cost) = queue.removeFirst()

        print("Visited \(origin)")
        
        if origin == target {
            if cost < cheapestCost {
                cheapestCost = cost
                cheapestRoute = route
            }
        }
        
        // Get neighbor cities
        if let neighbors = routes[origin] {
            for neighbor in neighbors {
                // Visit neighbor cities
                if !visited.contains(neighbor.key) {
                    // Track routes and costs
                    print("Visited \(neighbor.key)")
                    visited.insert(neighbor.key)
                    queue.append((neighbor.key, route + [neighbor.key], cost + neighbor.value))
                }
            }
        }
    }
}

let routes: [String: [String: Int]] = [
    "A": ["B": 1_000, "C": 200, "D": 500],
    "B": ["C": 700, "D": 800, "E": 750],
    "C": ["E": 1_200, "F": 400, "G": 500],
    "D": ["E": 800, "F": 700, "G": 450],
    "E": ["F": 600, "G": 900, "H": 1_100],
    "F": ["E": 600, "G": 600, "H": 950],
    "G": ["F": 600, "H": 300],
    "H": ["G": 300],
]

var visited2: Set<String> = []

var currentRoute: [String] = []
var cheapestRoute: [String] = []

var currentCost: Int = 0
var cheapestCost: Int = Int.max

dfsShortestRoute(routes: routes, origin: "A", target: "H", additionalCost: 0, &visited2, &currentRoute, &cheapestRoute, &currentCost, &cheapestCost)
print("DFS cheapest cost: \(cheapestCost), using route: \(cheapestRoute)\n")

bfsShortestRoute(routes: routes, origin: "A", target: "H", cheapestCost: &cheapestCost, cheapestRoute: &cheapestRoute)
print("BFS cheapest cost: \(cheapestCost), using route: \(cheapestRoute)\n")
